# UsersApi

All URIs are relative to *https://virtserver.swaggerhub.com/makr0n/Rbot/0.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createAuthUser**](UsersApi.md#createAuthUser) | **POST** /users | Метод регистрации/авторизации пользователя
[**deleteUserById**](UsersApi.md#deleteUserById) | **DELETE** /users/{id} | Метод удаления пользователя по id
[**getAllUsers**](UsersApi.md#getAllUsers) | **GET** /users | Метод получения списка пользователей

<a name="createAuthUser"></a>
# **createAuthUser**
> User createAuthUser(body)

Метод регистрации/авторизации пользователя

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UsersApi;


UsersApi apiInstance = new UsersApi();
Error body = new Error(); // Error | 
try {
    User result = apiInstance.createAuthUser(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling UsersApi#createAuthUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Error**](Error.md)|  |

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deleteUserById"></a>
# **deleteUserById**
> deleteUserById(id)

Метод удаления пользователя по id

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UsersApi;


UsersApi apiInstance = new UsersApi();
Integer id = 56; // Integer | Уникальный id пользователя
try {
    apiInstance.deleteUserById(id);
} catch (ApiException e) {
    System.err.println("Exception when calling UsersApi#deleteUserById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Уникальный id пользователя |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json

<a name="getAllUsers"></a>
# **getAllUsers**
> Users getAllUsers()

Метод получения списка пользователей

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UsersApi;


UsersApi apiInstance = new UsersApi();
try {
    Users result = apiInstance.getAllUsers();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling UsersApi#getAllUsers");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Users**](Users.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json, application/json

