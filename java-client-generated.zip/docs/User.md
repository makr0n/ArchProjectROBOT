# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**hash** | **Integer** |  | 
**question** | **String** | Контрольный вопрос пользователя | 
