package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Robot
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-02-19T22:39:02.719538592Z[GMT]")


public class Robot   {
  @JsonProperty("robot_id")
  private Integer robotId = null;

  @JsonProperty("model")
  private String model = null;

  @JsonProperty("serial_number")
  private String serialNumber = null;

  @JsonProperty("firware_version")
  private String firwareVersion = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("charge_level")
  private Integer chargeLevel = null;

  public Robot robotId(Integer robotId) {
    this.robotId = robotId;
    return this;
  }

  /**
   * Get robotId
   * @return robotId
   **/
  @Schema(example = "12", required = true, description = "")
      @NotNull

    public Integer getRobotId() {
    return robotId;
  }

  public void setRobotId(Integer robotId) {
    this.robotId = robotId;
  }

  public Robot model(String model) {
    this.model = model;
    return this;
  }

  /**
   * Get model
   * @return model
   **/
  @Schema(example = "Mark1", required = true, description = "")
      @NotNull

    public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public Robot serialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
    return this;
  }

  /**
   * Get serialNumber
   * @return serialNumber
   **/
  @Schema(example = "12A0B134KF", required = true, description = "")
      @NotNull

    public String getSerialNumber() {
    return serialNumber;
  }

  public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }

  public Robot firwareVersion(String firwareVersion) {
    this.firwareVersion = firwareVersion;
    return this;
  }

  /**
   * Get firwareVersion
   * @return firwareVersion
   **/
  @Schema(example = "1.32", description = "")
  
    public String getFirwareVersion() {
    return firwareVersion;
  }

  public void setFirwareVersion(String firwareVersion) {
    this.firwareVersion = firwareVersion;
  }

  public Robot status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  @Schema(example = "Производится уборка", required = true, description = "")
      @NotNull

    public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Robot chargeLevel(Integer chargeLevel) {
    this.chargeLevel = chargeLevel;
    return this;
  }

  /**
   * Get chargeLevel
   * @return chargeLevel
   **/
  @Schema(example = "66", required = true, description = "")
      @NotNull

    public Integer getChargeLevel() {
    return chargeLevel;
  }

  public void setChargeLevel(Integer chargeLevel) {
    this.chargeLevel = chargeLevel;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Robot robot = (Robot) o;
    return Objects.equals(this.robotId, robot.robotId) &&
        Objects.equals(this.model, robot.model) &&
        Objects.equals(this.serialNumber, robot.serialNumber) &&
        Objects.equals(this.firwareVersion, robot.firwareVersion) &&
        Objects.equals(this.status, robot.status) &&
        Objects.equals(this.chargeLevel, robot.chargeLevel);
  }

  @Override
  public int hashCode() {
    return Objects.hash(robotId, model, serialNumber, firwareVersion, status, chargeLevel);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Robot {\n");
    
    sb.append("    robotId: ").append(toIndentedString(robotId)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    serialNumber: ").append(toIndentedString(serialNumber)).append("\n");
    sb.append("    firwareVersion: ").append(toIndentedString(firwareVersion)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    chargeLevel: ").append(toIndentedString(chargeLevel)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
